#!/usr/bin/env python


#	Script Configuration. Replace these
#	values with your own.
#
#	scriptTitle		Self-explanatory
#
#	fetchURL		This holds the page that is to be
#					fetched from your domain.
#
#	searchString	This setting holds a string that
#					is going to be searched in the
#					fetched page.


scriptTitle 	= "Tutorialzine Dashboard"
fetchURL		= "http://www.google.com/"
searchString	= "Google"
